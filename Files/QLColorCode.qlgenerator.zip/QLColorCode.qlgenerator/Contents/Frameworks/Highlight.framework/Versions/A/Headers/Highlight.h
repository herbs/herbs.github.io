//
//  Highlight.h
//  Highlight
//
//  Created by Adam R. Maxwell on 04/11/10.
//  Copyright 2010 Adam R. Maxwell

/*
 This file is part of Highlight.
 
 Highlight is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 Highlight is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with Highlight.  If not, see <http://www.gnu.org/licenses/>.
 */

#import <Cocoa/Cocoa.h>

typedef int8_t HighlightOutputType;

// type constants to avoid the highlight namespace
extern const HighlightOutputType HighlightTypeHTML;
extern const HighlightOutputType HighlightTypeXHTML;
extern const HighlightOutputType HighlightTypeTEX;
extern const HighlightOutputType HighlightTypeLATEX;
extern const HighlightOutputType HighlightTypeRTF;
extern const HighlightOutputType HighlightTypeXML;
extern const HighlightOutputType HighlightTypeANSI;
extern const HighlightOutputType HighlightTypeXTERM256;
extern const HighlightOutputType HighlightTypeHTML32;
extern const HighlightOutputType HighlightTypeSVG;
extern const HighlightOutputType HighlightTypeBBCODE;

@interface Highlight : NSObject 
{
@private
    struct HighlightPriv *_ivars;
}

// uses HTML output by default
- (id)init;
- (id)initWithType:(HighlightOutputType)type;

// must be a theme existing in the Resources folder
- (void)setTheme:(NSString *)theme;

// typically a filename extension; will load filetypes.conf for additional mappings
- (void)setLanguage:(NSString *)language;

// font name, such as "Monaco"
- (void)setBaseFontName:(NSString *)fontName;

// must be > 0
- (void)setBaseFontSize:(CGFloat)fontSize;

// highlight's string output is converted to UTF-8 encoded data
- (NSData *)highlightString:(NSString *)source;

@end
